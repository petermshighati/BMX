const $ = (id) => document.getElementById(id);
let apiKey = "";
let currentEvents = [];
let latestOdds = {};
const HISTORY_KEY = "ot_prediction_history_v1";
const ODDS_HISTORY_KEY = "ot_odds_snapshots_v1";

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function fmtDate(iso) {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "Kick-off time unavailable" : d.toLocaleString([], {weekday:"short", day:"numeric", month:"short", hour:"2-digit", minute:"2-digit"});
}
function getHistory(){ try{return JSON.parse(localStorage.getItem(HISTORY_KEY)||"[]")}catch{return []} }
function setHistory(x){localStorage.setItem(HISTORY_KEY,JSON.stringify(x))}
function getOddsHistory(){try{return JSON.parse(localStorage.getItem(ODDS_HISTORY_KEY)||"{}")}catch{return {}}}
function setOddsHistory(x){localStorage.setItem(ODDS_HISTORY_KEY,JSON.stringify(x))}
function bestBook(event) {
  const books = event.bookmakers || [];
  const book = books.find(b => b.markets?.some(m => m.key === "h2h"));
  if(!book) return null;
  const market = book.markets.find(m => m.key === "h2h");
  const names = [event.home_team, "Draw", event.away_team];
  const prices = names.map(n => {
    const out = market.outcomes.find(o => o.name === n || (n==="Draw" && o.name.toLowerCase()==="draw"));
    return out && Number(out.price) > 1 ? Number(out.price) : null;
  });
  if(prices.some(p => p === null)) return null;
  const inv = prices.map(p=>1/p), total=inv.reduce((a,b)=>a+b,0);
  return {book:book.title||book.key, prices, probs:inv.map(p=>p/total*100), updated:market.last_update||book.last_update||event.commence_time};
}
function predictedIndex(probs){return probs.indexOf(Math.max(...probs))}
function saveOddsSnapshot(event, data) {
  const h=getOddsHistory(); const list=h[event.id]||[];
  list.push({at:new Date().toISOString(),prices:data.prices,book:data.book});
  h[event.id]=list.slice(-30); setOddsHistory(h);
}
function renderEvents() {
  const container=$("matches");
  if(!currentEvents.length){container.innerHTML='<div class="empty">No upcoming events returned for this league. Try another league or check your API plan.</div>';return;}
  container.innerHTML=currentEvents.map(ev=>{
    const o=latestOdds[ev.id];
    if(!o) return `<article class="match"><div class="teams">${escapeHtml(ev.home_team)} vs ${escapeHtml(ev.away_team)}</div><div class="meta">${fmtDate(ev.commence_time)}</div><div class="empty">No complete 1X2 market from the selected bookmakers.</div></article>`;
    const probs=o.probs.map(n=>n.toFixed(1));
    const labels=["1 · Home","X · Draw","2 · Away"];
    const pred=predictedIndex(o.probs);
    const snapshots=(getOddsHistory()[ev.id]||[]);
    const previous=snapshots.length>1?snapshots[snapshots.length-2]:null;
    const move=previous?o.prices.map((p,i)=>p-previous.prices[i]):null;
    return `<article class="match">
      <div class="teams">${escapeHtml(ev.home_team)} <span class="muted">vs</span> ${escapeHtml(ev.away_team)}</div>
      <div class="meta">${fmtDate(ev.commence_time)} · ${escapeHtml(o.book)} · updated ${fmtDate(o.updated)}</div>
      <div class="odds">${o.prices.map((p,i)=>`<div class="odd"><span>${labels[i]}</span><b>${p.toFixed(2)}</b>${move?`<span>${move[i]>0.001?"▲":move[i]<-0.001?"▼":"—"} ${Math.abs(move[i]).toFixed(2)}</span>`:""}</div>`).join("")}</div>
      <div class="probs">Normalized implied probabilities: ${probs[0]}% / ${probs[1]}% / ${probs[2]}%</div>
      <div class="cardactions"><span class="pill">Highest implied chance: ${["Home win","Draw","Away win"][pred]}</span><button class="small" data-save="${escapeHtml(ev.id)}">Save prediction</button></div>
    </article>`;
  }).join("");
  container.querySelectorAll("[data-save]").forEach(btn=>btn.addEventListener("click",()=>savePrediction(btn.dataset.save)));
}
function savePrediction(id){
  const ev=currentEvents.find(e=>e.id===id), o=latestOdds[id]; if(!ev||!o)return;
  const p=predictedIndex(o.probs);
  const h=getHistory();
  h.unshift({id,home:ev.home_team,away:ev.away_team,kickoff:ev.commence_time,book:o.book,prices:o.prices,probs:o.probs,pick:["1","X","2"][p],pickName:["Home win","Draw","Away win"][p],savedAt:new Date().toISOString(),result:"Pending"});
  setHistory(h.slice(0,200)); renderHistory(); alert("Prediction saved to history.");
}
function renderHistory(){
  const h=getHistory(), c=$("history");
  if(!h.length){c.innerHTML='<div class="empty">No predictions saved yet.</div>';return;}
  c.innerHTML=h.map((x,i)=>`<article class="match"><div class="teams">${escapeHtml(x.home)} vs ${escapeHtml(x.away)}</div><div class="meta">Saved ${fmtDate(x.savedAt)} · Kick-off ${fmtDate(x.kickoff)}</div><div class="odds">${x.prices.map((p,j)=>`<div class="odd"><span>${["1 · Home","X · Draw","2 · Away"][j]}</span><b>${Number(p).toFixed(2)}</b></div>`).join("")}</div><div class="cardactions"><span class="pill">Pick: ${escapeHtml(x.pick)} — ${escapeHtml(x.pickName)}</span><select data-result="${i}" aria-label="Set match result"><option ${x.result==="Pending"?"selected":""}>Pending</option><option ${x.result==="1"?"selected":""} value="1">Result: Home win</option><option ${x.result==="X"?"selected":""} value="X">Result: Draw</option><option ${x.result==="2"?"selected":""} value="2">Result: Away win</option></select></div><div class="probs">Implied chance at save: ${x.probs.map(n=>Number(n).toFixed(1)+"%").join(" / ")}</div></article>`).join("");
  c.querySelectorAll("[data-result]").forEach(s=>s.addEventListener("change",()=>{const items=getHistory();items[Number(s.dataset.result)].result=s.value;setHistory(items);renderHistory()}));
}
async function loadOdds(){
  apiKey=$("apiKey").value.trim();
  if(!apiKey){$("error").textContent="Paste your API key first.";return;}
  const sport=$("league").value, regions=$("regions").value;
  $("loadBtn").disabled=true; $("error").textContent=""; $("status").textContent="Loading…";
  try{
    const url=`https://api.the-odds-api.com/v4/sports/${encodeURIComponent(sport)}/odds/?regions=${encodeURIComponent(regions)}&markets=h2h&oddsFormat=decimal&apiKey=${encodeURIComponent(apiKey)}`;
    const response=await fetch(url);
    if(!response.ok) throw new Error(response.status===401||response.status===403?"API key rejected or plan does not include this league.":`API returned HTTP ${response.status}. Check key, league access and quota.`);
    const data=await response.json();
    if(!Array.isArray(data)) throw new Error("Unexpected API response. Check that you selected The Odds API v4.");
    currentEvents=data; latestOdds={};
    data.forEach(ev=>{const o=bestBook(ev);if(o){latestOdds[ev.id]=o;saveOddsSnapshot(ev,o)}});
    $("loadedAt").textContent=`Loaded ${data.length} events · ${new Date().toLocaleTimeString()}`;
    $("status").textContent="Connected";
    renderEvents();
  }catch(e){$("error").textContent=`Could not load odds: ${e.message} If the browser blocks the request, use a provider/backend proxy that supports web requests; never expose a production API key in a public app.`;$("status").textContent="Error";}
  finally{$("loadBtn").disabled=false;}
}
$("loadBtn").addEventListener("click",loadOdds);
$("refreshBtn").addEventListener("click",loadOdds);
$("clearKeyBtn").addEventListener("click",()=>{$("apiKey").value="";apiKey="";$("status").textContent="Not connected";$("error").textContent="API key cleared from this page."});
$("clearHistoryBtn").addEventListener("click",()=>{if(confirm("Delete all saved predictions on this device?")){setHistory([]);renderHistory()}});
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));
  $("matchesView").hidden=b.dataset.tab!=="matches";$("historyView").hidden=b.dataset.tab!=="history";
}));
renderHistory();
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
